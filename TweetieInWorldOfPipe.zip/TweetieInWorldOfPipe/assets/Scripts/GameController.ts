import { _decorator, CCInteger, Component,KeyCode ,EventKeyboard, Input,input, Node, director , Contact2DType , Collider2D , IPhysics2DContact} from 'cc';
import { Ground } from './Ground';
import { Results } from './Results';
import { Bird } from './Bird';
import { PipePool } from './PipePool';
const { ccclass, property } = _decorator;


@ccclass('GameController')
export class GameController extends Component {

    @property({
        type:Ground,
        tooltip:'this is ground'
    })
    public ground: Ground

    @property({
        type:Results,
        tooltip:'Results go here'
    })
    public result:Results
    
    @property({
        type:Bird
    })
    public bird:Bird;
    
    @property({
        type:PipePool
    })
    public pipeQueue:PipePool;

    @property({
        type: CCInteger
    })
    public speed: number= 300;

    @property({
        type:CCInteger
    })
    public pipeSpeed:number = 200;

    public isOver:boolean;
    protected onLoad(): void {
        this.initListener();
        this.result.resetScore();
        this.isOver = true;
        director.pause();
    }

    initListener(){
        input.on(Input.EventType.KEY_DOWN, this.onKeyDown,this);
        console.log("COMING HERE in initListener")
        // this.node.on(Node.EventType.TOUCH_START,()=>{
        //     if(this.isOver==true){
        //         this.resetGame();
        //         this.bird.resetBird();
        //         this.startGame();
        //     }
        //     if(this.isOver==false){
        //         this.bird.fly();
        //     }
        // })
    }
    //Only For testing
    onKeyDown(event: EventKeyboard){
        if(this.isOver==true){
            this.resetGame();
            this.bird.resetBird();
            this.startGame();
        }
        if(this.isOver==false){
            this.bird.fly();
        }
    }

    startGame(){
        this.result.hideResults();
        director.resume();
    }

    gameOver(){
        this.result.showResults();
        this.isOver= true;
        director.pause();
    }

    resetGame() {
        this.result.resetScore();
        this.pipeQueue.reset();
        this.isOver= false;
        this.startGame();
    }

    passPipe(){
        this.result.addScore();
    }

    createPipe(){
        this.pipeQueue.addPool();
    }

    contactGroundPipe(){
        let collider = this.bird.getComponent(Collider2D)

        if(collider){
            collider.on(Contact2DType.BEGIN_CONTACT , this.onBeginContact , this)
        }
    }

    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D ,contact:IPhysics2DContact|null){
        this.bird.hitSomething = true;
    }

    birdStruck(){
        this.contactGroundPipe();

        if(this.bird.hitSomething==true){
            this.gameOver();
        }
    }

    update(){
        if(this.isOver==false){
            this.birdStruck();
        }
    }
}


